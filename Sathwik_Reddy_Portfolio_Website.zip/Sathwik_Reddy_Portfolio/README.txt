SATHWIK REDDY — PORTFOLIO WEBSITE

FILES
- index.html : website structure and content
- style.css  : dark modern responsive design and animations
- script.js  : mobile menu, scroll reveal, active navigation, copy-email button

HOW TO RUN
1. Extract the ZIP file.
2. Open the folder in VS Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.

IMPORTANT CUSTOMIZATION
- College name is set to Uttaranchal University.
- Three sample project entries are included: AI Resume Analyzer, AI-Based Smart Traffic Optimization, and Emotion Detection from Text. Keep them only if Sathwik has actually built them; otherwise replace them with completed projects.
- Add actual certificates/achievements in the certificates section.
- Update the skill-bar widths in style.css to reflect actual skill levels.
- Add a real profile photo if desired; the current SR initials are a designed placeholder.
- LinkedIn, GitHub, and phone number were not supplied, so they are not invented.

The project cards are placeholders and should be replaced before final college submission.
